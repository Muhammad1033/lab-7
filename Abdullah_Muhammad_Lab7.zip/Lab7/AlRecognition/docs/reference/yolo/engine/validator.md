# BaseValidator
---
:::ultralytics.yolo.engine.validator.BaseValidator
<br><br>
