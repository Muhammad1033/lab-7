# DetectionPredictor
---
:::ultralytics.yolo.v8.detect.predict.DetectionPredictor
<br><br>

# predict
---
:::ultralytics.yolo.v8.detect.predict.predict
<br><br>
