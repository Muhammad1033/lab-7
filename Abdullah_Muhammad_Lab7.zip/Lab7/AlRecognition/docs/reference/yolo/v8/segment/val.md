# SegmentationValidator
---
:::ultralytics.yolo.v8.segment.val.SegmentationValidator
<br><br>

# val
---
:::ultralytics.yolo.v8.segment.val.val
<br><br>
