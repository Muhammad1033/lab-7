# PoseValidator
---
:::ultralytics.yolo.v8.pose.val.PoseValidator
<br><br>

# val
---
:::ultralytics.yolo.v8.pose.val.val
<br><br>
