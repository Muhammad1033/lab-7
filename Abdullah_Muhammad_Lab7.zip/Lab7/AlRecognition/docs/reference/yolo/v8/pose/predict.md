# PosePredictor
---
:::ultralytics.yolo.v8.pose.predict.PosePredictor
<br><br>

# predict
---
:::ultralytics.yolo.v8.pose.predict.predict
<br><br>
