# VarifocalLoss
---
:::ultralytics.yolo.utils.loss.VarifocalLoss
<br><br>

# BboxLoss
---
:::ultralytics.yolo.utils.loss.BboxLoss
<br><br>

# KeypointLoss
---
:::ultralytics.yolo.utils.loss.KeypointLoss
<br><br>
