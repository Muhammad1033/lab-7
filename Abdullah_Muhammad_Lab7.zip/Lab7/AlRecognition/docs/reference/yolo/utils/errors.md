# HUBModelError
---
:::ultralytics.yolo.utils.errors.HUBModelError
<br><br>
